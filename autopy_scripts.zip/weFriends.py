import importlib
import queue
import traceback
import time
from Log import Log
from com.xiaoyuan.weHelper import AutoService
from android.view.accessibility import AccessibilityEvent
importlib.reload(importlib.import_module("_UiUtil"))
from _UiUtil import UiUtil
importlib.reload(importlib.import_module("_TopMenu"))
from _TopMenu import TopMenu
importlib.reload(importlib.import_module("_weMoments"))
from _weMoments import Moments, MomentForwardHelp
from _ThreadTask import ThreadTask
from _global import G
from _FullScreenNotification import FullNotification
from _LastActivity import LastActivity
importlib.reload(importlib.import_module("_PersonMomentsHandler"))
from _PersonMomentsHandler import personMomentsHandler
from _CloneFriendMements import cloneMoments
personMomentsHandler.menu.cloneFunc = cloneMoments

def forwardMoment(moment):
    FullNotification.show("正在自动化操作，请不要操作手机, 否则会导致转发中断。。。。", "")
    # FullNotification.touchable(True)
    G().forwardMomentOngoing = True
    MomentForwardHelp.forward(moment)
    G().forwardMomentOngoing = False
    FullNotification.hide()


class EventHandle:
    events = queue.Queue()
    weMomentForwardSubMenu = TopMenu(UiUtil.getApplication())

    def addEvent(event):
        LastActivity.log(event)
        # packageName = event.getPackageName()
        # if packageName and packageName == "com.tencent.mm":
        # Log.log(f"put {str(event).split(';')[0]}::: {event.getEventType()}")
        EventHandle.events.put((AccessibilityEvent(event), event.getSource(), time.time()))

    def run():
        while True:
            try:
                event, source, eventTime = EventHandle.events.get(timeout=0.1)
                EventHandle._handle(event, source, eventTime)
            except SystemExit:
                Log.log("Thread stopped...")
                break
            except queue.Empty:
                pass
            except Exception:
                Log.log(str(traceback.format_exc()))

    def _handle(event, source, eventTime):
        if G().lastHander is not None:
            if eventTime < G().lastHander:
                return
        personMomentsHandler.handle(event, EventHandle.events)
        EventHandle.handleForward(event, source, eventTime)

    def _isCurrentIn(packageName, activity):
        if packageName not in UiUtil.getPackageName():
            return False
        return activity in LastActivity.getActivity(packageName)

    def handleForward(event, source, eventTime):
        if event.getEventType() != AccessibilityEvent.TYPE_VIEW_CLICKED:
            return
        if source is None:
            return
        if G().forwardMomentOngoing:
            return
        moments = None
        if EventHandle._isCurrentIn("com.tencent.mm", ".ImproveSnsTimelineUI"):
            moments = Moments()
            moments.getCurrentMoments()
        elif EventHandle._isCurrentIn("com.tencent.mm", ".SnsCommentDetailUI"):
            moments = Moments()
            moments.getSingleMoment()
        if moments is not None:
            moment = moments.getDotBtnClickMoment(source)
            if moment is None:
                return
            # moment.show()
            rect = moment.getRect()
            EventHandle.weMomentForwardSubMenu.setMenu((
                ("手动转发", lambda: ThreadTask.run(forwardMoment, None, args=(moment,))),
                ("自动转发",)))
            EventHandle.weMomentForwardSubMenu.show(rect.right, rect.bottom)


Log.log("run AccessibiltyEventHandler")
ThreadTask.run(EventHandle.run, "AccessibiltyEventHandler")


# 单条朋友圈详情页
# UiUtil.startApp("com.tencent.mm","com.tencent.mm.plugin.sns.ui.SnsCommentDetailUI") 
# 朋友或自己单个人的朋友圈
# UiUtil.startApp("com.tencent.mm","com.tencent.mm.plugin.sns.ui.SnsUserUI")
# 朋友详情页
# UiUtil.startApp("com.tencent.mm","com.tencent.mm.plugin.profile.ui.ContactInfoUI")
# 朋友圈
# UiUtil.startApp("com.tencent.mm","com.tencent.mm.plugin.sns.ui.improve.ImproveSnsTimelineUI")

def handle(event):
    if not AutoService.isConnected():
        return
    # Log.log(f"{event.getPackageName()} {str(event).split(';')[0]}")
    EventHandle.addEvent(event)
