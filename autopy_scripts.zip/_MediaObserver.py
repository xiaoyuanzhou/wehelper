import queue
from android.provider import MediaStore
from android.os import Handler
from android.database import ContentObserver
from _JavaProxy import JavaProxy
from _MainThreadTask import MainThreadTask
from com.xiaoyuan.weHelper import AutoService


class MediaObserver:
    Images = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
    Video = MediaStore.Video.Media.EXTERNAL_CONTENT_URI

    def __init__(self):
        self.observer = None

    @staticmethod
    def monitor(type):
        obs = MediaObserver()
        def register(self, type):
            self.observer = _MediaObserver(Handler())
            AutoService.getInstance().getContentResolver().registerContentObserver(
                type, True, self.observer.toJava())
        MainThreadTask().run(register, obs, type).wait()
        return obs.observer


@JavaProxy(ContentObserver)
class _MediaObserver:
    def wait(self, timeout=20, exception=False):
        for i in range(int(timeout*10)):
            try:
                self.notify.get(timeout=0.1)
                if exception:
                    return self
                return True
            except queue.Empty as e:
                pass
        if exception:
            self.stop()
            raise Exception("MediaObserver wait Timeout.")
        return False

    def stop(self):
        if self.stoped:
            return
        self.stoped = True
        def _f():
            AutoService.getInstance().getContentResolver().unregisterContentObserver(self.toJava())
        MainThreadTask().run(_f).wait()
        return self

    def __init__(self, handler):
        self.notify = queue.Queue()
        self.stoped = False

    def onChange(self, selfChange, uri=None, flags=0):
        # Log.log(uri)
        if uri is not None:
            self.notify.put(1)

