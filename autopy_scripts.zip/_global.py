class G:
    o = {}

    def __getattr__(self, name):
        return G.get(name)

    def __setattr__(self, name, value):
        G.o[name]=value

    def get(name, default=None):
        if name not in G.o:
            G.o[name] = default
        return G.o[name]

