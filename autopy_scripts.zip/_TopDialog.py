from android.os import Build
from android.graphics import PixelFormat
from android.view import View
from android.view import WindowManager
from android.widget import ArrayAdapter
from android.widget import LinearLayout, TextView
from android.widget import ListView, Button
from android.widget import CheckBox
from android.graphics import Color
from android.content import Context
from androidx.constraintlayout.widget import ConstraintLayout
from java import jarray, jint
from java.lang import Object
from com.xiaoyuan.weHelper import AutoService

from _MainThreadTask import MainThreadTask
from _ConcreteClickProxy import OnItemClickListenerProxy, OnClickListenerProxy
from _JavaProxy import JavaProxy, JavaInt
from _WindowManager import WindowManagerHelper
from Log import Log


@JavaProxy(ArrayAdapter, Context, JavaInt, jarray(Object))
class ItemAdapter:
    def __init__(self, context, resource, objs, data) -> None:
        self.data = data
        pass

    def getView(self, position, convertView, parent):
        obj = self.data[position]
        if convertView:
            convertView.setText(obj.title)
            convertView.setChecked(obj.isChecked)
            return convertView
        checkBox = CheckBox(AutoService.getInstance())
        checkBox.setId(2)
        checkBoxParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT,
                3.0)
        checkBox.setLayoutParams(checkBoxParams)
        checkBox.setText(obj.title)
        checkBox.setFocusable(False)
        checkBox.setClickable(False)
        checkBox.setChecked(obj.isChecked)
        return checkBox

class DialogView:
    def getView(self):
        return self.constraintLayout

    def setListItem(self, data):
        self.adapter = ItemAdapter(
            AutoService.getInstance(), jint(0), ["" for _ in data],
            data=data)
        self.listView.setAdapter(self.adapter.proxied)

    def updateList(self):
        self.adapter.notifyDataSetChanged()

    def setOnItemClick(self, handler):
        self.listView.setOnItemClickListener(
            OnItemClickListenerProxy(handler))

    def setOnCancel(self, handler):
        self.cancel.setOnClickListener(OnClickListenerProxy(handler))

    def setOnOk(self, handler):
        self.ok.setOnClickListener(OnClickListenerProxy(handler))

    def __init__(self, name) -> None:
        constraintLayout = ConstraintLayout(AutoService.getInstance())
        constraintLayout.setLayoutParams(ConstraintLayout.LayoutParams(
            ConstraintLayout.LayoutParams.MATCH_PARENT,
            ConstraintLayout.LayoutParams.MATCH_PARENT))
        constraintLayout.setBackgroundColor(Color.WHITE)

        clone = TextView(AutoService.getInstance())
        clone.setId(View.generateViewId())
        clone.setText("克隆")
        clone.setTextSize(24)
        cloneParams = ConstraintLayout.LayoutParams(
            ConstraintLayout.LayoutParams.WRAP_CONTENT,
            ConstraintLayout.LayoutParams.WRAP_CONTENT)
        cloneParams.topToTop = ConstraintLayout.LayoutParams.PARENT_ID
        cloneParams.startToStart = ConstraintLayout.LayoutParams.PARENT_ID
        cloneParams.endToEnd = ConstraintLayout.LayoutParams.PARENT_ID
        clone.setLayoutParams(cloneParams)
        constraintLayout.addView(clone)
        
        toname = TextView(AutoService.getInstance())
        toname.setId(View.generateViewId())
        toname.setText(f"批量转发 {name} 的朋友圈")
        tonameParams = ConstraintLayout.LayoutParams(
            ConstraintLayout.LayoutParams.WRAP_CONTENT,
            ConstraintLayout.LayoutParams.WRAP_CONTENT)
        tonameParams.topToBottom = clone.getId()
        tonameParams.startToStart = ConstraintLayout.LayoutParams.PARENT_ID
        tonameParams.endToEnd = ConstraintLayout.LayoutParams.PARENT_ID
        toname.setLayoutParams(tonameParams)
        constraintLayout.addView(toname)
        
        note = TextView(AutoService.getInstance())
        note.setId(View.generateViewId())
        note.setText(f"如果看不到需要转发的那条动态，先取消，浏览到指定的动态后再点克隆")
        noteParams = ConstraintLayout.LayoutParams(
            ConstraintLayout.LayoutParams.WRAP_CONTENT,
            ConstraintLayout.LayoutParams.WRAP_CONTENT)
        noteParams.topToBottom = toname.getId()
        noteParams.startToStart = ConstraintLayout.LayoutParams.PARENT_ID
        noteParams.endToEnd = ConstraintLayout.LayoutParams.PARENT_ID
        note.setLayoutParams(noteParams)
        constraintLayout.addView(note)

        ok = Button(AutoService.getInstance())
        ok.setId(View.generateViewId())
        ok.setText("转发")
        okParams = ConstraintLayout.LayoutParams(
            ConstraintLayout.LayoutParams.WRAP_CONTENT,
            ConstraintLayout.LayoutParams.WRAP_CONTENT)
        okParams.bottomToBottom = ConstraintLayout.LayoutParams.PARENT_ID
        okParams.endToEnd = ConstraintLayout.LayoutParams.PARENT_ID
        ok.setLayoutParams(okParams)
        constraintLayout.addView(ok)

        cancel = Button(AutoService.getInstance())
        cancel.setId(View.generateViewId())
        cancel.setText("取消")
        cancelParams = ConstraintLayout.LayoutParams(
            ConstraintLayout.LayoutParams.WRAP_CONTENT,
            ConstraintLayout.LayoutParams.WRAP_CONTENT)
        cancelParams.bottomToBottom = ConstraintLayout.LayoutParams.PARENT_ID
        cancelParams.endToStart = ok.getId()
        cancel.setLayoutParams(cancelParams)
        constraintLayout.addView(cancel)

        listView = ListView(AutoService.getInstance())
        listViewParams = ConstraintLayout.LayoutParams(
            ConstraintLayout.LayoutParams.WRAP_CONTENT, 0)
        listViewParams.topToBottom = note.getId()
        listViewParams.bottomToTop = cancel.getId()
        listViewParams.startToStart = ConstraintLayout.LayoutParams.PARENT_ID
        listViewParams.endToEnd = ConstraintLayout.LayoutParams.PARENT_ID
        listView.setLayoutParams(listViewParams)
        constraintLayout.addView(listView)
        self.constraintLayout = constraintLayout
        self.listView = listView
        self.ok = ok
        self.cancel = cancel


class TopDialog:
    def __init__(self, name, cloneFunc) -> None:
        self.menu = None
        self.menuView = None
        self.name = name
        self.cloneFunc = cloneFunc

    def forward(self, view=None):
        Log.logm("forward...")
        needForwardMoments = []
        for menu in self.menu:
            if menu.isChecked:
                Log.logm("forward:", menu.ind)
                needForwardMoments.append(menu.ind)
        self.hide()
        Log.logm("forward", needForwardMoments)
        if self.cloneFunc:
            Log.logm("forward start...", needForwardMoments)
            self.cloneFunc(self.name, needForwardMoments)

    def setMenu(self, menu):
        self.menu = menu

    def show(self):
        MainThreadTask().run(self._show).wait()

    def _show(self):
        if self.menuView is not None:
            return
        if self.menu is None:
            return
        dv = DialogView(self.name)
        dv.setListItem(self.menu)
        dv.setOnCancel(self.hide)
        dv.setOnOk(self.forward)
        dv.setOnItemClick(self._onMenuItemClick)
        self.menuView = dv
        layoutParams = self._createLayoutParams()
        WindowManagerHelper.addView(self.menuView.getView(), layoutParams)

    def hide(self, view=None):
        MainThreadTask().run(self._hide).wait()

    def _hide(self):
        if self.menuView is None:
            return
        WindowManagerHelper.removeView(self.menuView.getView())
        self.menuView = None

    def _onMenuItemClick(self, position):
        if position >= len(self.menu):
            return
        menu = self.menu[position]
        menu.isChecked = False if menu.isChecked else True
        self.menuView.updateList()

    def _createLayoutParams(self):
        layoutParams = WindowManager.LayoutParams()
        layoutParams.x = 0
        layoutParams.y = 0
        layoutParams.width = WindowManager.LayoutParams.MATCH_PARENT
        layoutParams.height = WindowManager.LayoutParams.MATCH_PARENT
        layoutParams.flags = (WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                            | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                            | WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH
                            | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN)
        layoutParams.format = PixelFormat.RGBA_8888
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O):
            layoutParams.type = WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY
        else:
            layoutParams.type = WindowManager.LayoutParams.TYPE_TOAST
        return layoutParams
