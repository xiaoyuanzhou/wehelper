from Log import Log
from com.xiaoyuan.weHelper import AutoService
# from runFileTask import FileTask
from _VersionUpdateChecker import VersionUpdateChecker
from _OnePixelShow import OnePixelShow

def hello():
    Log.log("Hello AutoPy!!!.....")
    # Log.log("Start PlayerMusicService...")
    # UiUtil.startService(PlayerMusicService)
    Log.log(f"AutoService.isConnected {AutoService.isConnected()}")
    if not AutoService.isConnected():
        return False
    OnePixelShow.show()
    Log.log("OnePixelShow.show()")
    AutoService.getInstance().registerHandler("weFriends", "handle")
    Log.log("AutoService.getInstance().registerHandler")

VersionUpdateChecker.rerunIfVersionUpdated()
hello()
