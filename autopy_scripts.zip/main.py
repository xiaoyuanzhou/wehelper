from Log import Log
from com.xiaoyuan.weHelper import AutoService
# from runFileTask import FileTask
from _VersionUpdateChecker import VersionUpdateChecker

def hello():
    Log.log("Hello AutoPy!!!.....")
    # Log.log("Start PlayerMusicService...")
    # UiUtil.startService(PlayerMusicService)
    Log.log(f"AutoService.isConnected {AutoService.isConnected()}")
    if not AutoService.isConnected():
        return False
    AutoService.getInstance().registerHandler("weFriends", "handle")

VersionUpdateChecker.rerunIfVersionUpdated()
hello()
