import time
import importlib
importlib.reload(importlib.import_module("UiUtil"))
from UiUtil import (UiUtil,
                    TextView, ListView)
from _PersonMomentsHandler import personMomentsHandler
from Log import Log
from _ThreadTask import ThreadTask
from _weMoments import Moments, MomentForwardHelp
from _WechatUIHelper import WechatUIHelper
from _FullScreenNotification import FullNotification


class CloneFriendMements:
    def clone(who, ind):
        try:
            WechatUIHelper.gotoMainUi()
            personMomentsHandler.cleanMoments()
            WechatUIHelper.gotoFriend(who)
            WechatUIHelper.gotoMoments(who)
            CloneFriendMements.gotoMoment(ind)
            CloneFriendMements.forwardMoment()
        except Exception as e:
            Log.log(e)
            return False
        return True

    def forwardMoment():
        UiUtil.waitFor(personMomentsHandler.isInSnsCommentDetailUI, timeout=3)
        time.sleep(0.5)
        moments = Moments()
        moments.getSingleMoment()
        if len(moments.moments) == 0:
            raise Exception("读取朋友圈失败")
        MomentForwardHelp.forward(moments.moments[0], True)

    def gotoMoment(ind):
        UiUtil.waitFor(personMomentsHandler.isInSnsUserUI, timeout=3)
        frientMoments = ListView()
        winRect = UiUtil.getBoundsInScreen(UiUtil.getRootNode())
        TextView(text="正在加载..").waitDisappear()
        moment = personMomentsHandler.getMomentsInScreen(ind, winRect)
        while moment is None:
            if len(personMomentsHandler.moments.moments) > ind + 20:
                raise Exception("该记录被跳过")
            if TextView(text="仅展示").exist(timeout=0.5):
                raise Exception("该记录不存在")
            UiUtil.waitFor(personMomentsHandler.isInSnsUserUI, timeout=0)
            frientMoments.scrollForward()
            TextView(text="正在加载..").waitDisappear(wait=0.2)
            moment = personMomentsHandler.getMomentsInScreen(ind, winRect)
        moment.right.click(gesture=True, duration=10)


def cloneMoments(to, inds):
    def task():
        Log.log(f"Start Run Clone {to} Moments...")
        FullNotification.show("正在自动化操作，请不要操作手机, 否则会导致转发中断。。。。", f"开始克隆{to}的朋友圈")
        indcount = len(inds)
        for i in range(indcount):
            ind = inds[i]
            FullNotification.setNotifyText(f"({i}/{indcount})正在克隆{to}第{ind}条朋友圈...")
            if not CloneFriendMements.clone(to, ind):
                FullNotification.setNotifyText("克隆失败")
                break
        FullNotification.hide()
        Log.logm("Clone Friend Moments Finished")
    ThreadTask.run(task=task, taskName="runBatchForwardMoment")
