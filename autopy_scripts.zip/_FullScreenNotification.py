from android.graphics import PixelFormat
from android.os import Build
from android.view import WindowManager
from android.widget import LinearLayout
from android.widget import TextView
from android.graphics import Color
from android.view import Gravity
from com.xiaoyuan.weHelper import AutoService
from _MainThreadTask import MainThreadTask
from _WindowManager import WindowManagerHelper


class FullNotification:
    view = None
    def createView(header, context):
        if FullNotification.view is not None:
            return
        layout = LinearLayout(AutoService.getInstance())
        layout.setOrientation(LinearLayout.VERTICAL)
        layout.setGravity(Gravity.CENTER_VERTICAL)
        layout.setBackgroundColor(Color.parseColor("#FF673AB7"))
        
        textView = TextView(AutoService.getInstance())
        textView.setText(header)
        textView.setTextColor(Color.WHITE)
        params = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        )
        margin = 20
        params.setMargins(margin, margin, margin, margin)
        params.gravity = Gravity.CENTER
        textView.setLayoutParams(params)
        textView.setBackgroundColor(Color.parseColor("#FF673AB7"))
        layout.addView(textView)
        
        notifyText = TextView(AutoService.getInstance())
        notifyText.setId(999)
        notifyText.setText(context)
        notifyText.setTextColor(Color.WHITE)
        params = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        )
        params.setMargins(margin, margin, margin, margin)
        params.gravity = Gravity.CENTER
        notifyText.setLayoutParams(params)
        notifyText.setBackgroundColor(Color.parseColor("#FF673AB7"))
        layout.addView(notifyText)

        FullNotification.view = layout

    def createParams():
        margin = 20
        w, h = WindowManagerHelper.getWinSize()
        params = WindowManager.LayoutParams(
            int(w-2*margin),
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|
                WindowManager.LayoutParams.FLAG_FULLSCREEN |
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE|
                WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS|
                WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
            PixelFormat.TRANSLUCENT)
        if Build.VERSION.SDK_INT < 26: #Build.VERSION_CODES.O
            params.type = WindowManager.LayoutParams.TYPE_TOAST
        params.x = margin
        params.y = int(h/4)
        params.gravity = Gravity.LEFT | Gravity.TOP
        params.alpha = 0.7
        return params

    def setNotifyText(context):
        if FullNotification.view is None:
            return
        def _f():
            notifyText = FullNotification.view.findViewById(999)
            notifyText.setText(context)
        MainThreadTask().run(_f).wait()

    def show(title, context):
        def _f():
            FullNotification.createView(title, context)
            params = FullNotification.createParams()

            WindowManagerHelper.addView(FullNotification.view, params)
        MainThreadTask().run(_f).wait()

    def touchable(flag):
        if FullNotification.view is None:
            return
        def _f():
            params = FullNotification.createParams()
            if flag:
                params.flags &= ~WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
            WindowManagerHelper.updateViewLayout(FullNotification.view, params)
        MainThreadTask().run(_f).wait()

    def hide():
        if FullNotification.view is None:
            return
        def _f():
            WindowManagerHelper.removeView(FullNotification.view)
            FullNotification.view = None
        MainThreadTask().run(_f).wait()


