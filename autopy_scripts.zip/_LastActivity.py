import threading

class LastActivity:
    activity = {}
    x_lock = threading.Lock()

    def log(event):
        with LastActivity.x_lock:
            className = event.getClassName()
            if className is None:
                return
            packageName = event.getPackageName()
            if packageName in className:
                LastActivity.activity[packageName] = className
                # Log.log(f"{packageName} {className}")

    def getActivity(packageName):
        with LastActivity.x_lock:
            if packageName not in LastActivity.activity:
                return ""
            return LastActivity.activity[packageName]

