import os
import urllib.request
try:
    from Log import Log
except:
    class Log:
        @staticmethod
        def log(*arg):
            pass

class Net:
    _urls = ["https://wehelper.aimiyanxuan.com/", "https://dbbt94a5jhuj9.cloudfront.net/", "https://wehelper.aimiyanxuan_abcd.com/"]
    _currentVersion = 1_000_004

    def versionUpdated():
        newVersion = Net.getNewVersion()
        Log.log(f"currentVersion: {Net.getCurVersion()}, newVersion: {newVersion}")
        return newVersion > Net.getCurVersion()

    def getNewScript():
        path = "autopy_scripts.zip"
        dest = os.path.join(os.path.dirname(__file__), path)
        for url in Net._urls:
            if Net.download(url + path, dest):
                return dest
        return None

    def getNewVersion():
        path = "version.html"
        for url in Net._urls:
            version = Net.getUrl(url + path)
            if version:
                return int(version)
        return Net.getCurVersion()

    def getCurVersion():
        return Net._currentVersion

    def getUrl(url):
        try:
            with urllib.request.urlopen(url) as response:
                if 200 == response.getcode():
                    return response.read()
        except urllib.error.HTTPError as e:
            Log.log(e)
        except urllib.error.URLError as e:
            Log.log(e)
        return None
    
    def download(url, dest):
        try:
            urllib.request.urlretrieve(url, dest)
            return True
        except urllib.error.HTTPError as e:
            # Log.log(e)
            pass
        except urllib.error.URLError as e:
            Log.log(e)
        return False
