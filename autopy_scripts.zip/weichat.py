from Log import Log
from com.xiaoyuan.weHelper import AutoService
from android.os import PowerManager
from android.content import Context
import os
import time
from Timer import Timer
import random
import importlib
importlib.reload(importlib.import_module("_UiUtil"))
from _UiUtil import ViewGroup, ImageView, ImageButton, Button, TextView, EditText, RelativeLayout, UiUtil
from _ThreadTask import ThreadTask

def inputPassword(passwd):
    mima = EditText(description="密码区域", viewId="com.android.systemui:id/fixedPinEntry")
    if not mima.exist(3):
        return
    for p in passwd:
        btn = ViewGroup(viewId="com.android.systemui:id/key"+p)
        btn.click()

def unlockScreen():
    pm = UiUtil.getApplication().getSystemService(Context.POWER_SERVICE)
    while not pm.isScreenOn():
        mWakeLock = pm.newWakeLock(
            PowerManager.SCREEN_BRIGHT_WAKE_LOCK
            | PowerManager.ACQUIRE_CAUSES_WAKEUP, "myapp:bright")
        mWakeLock.acquire(10000)
        mWakeLock.release()
    while UiUtil.getPackageName() == "com.android.systemui":
        UiUtil.click(50, 1000, 50, 150, 500)
        time.sleep(0.5)

def waitForPackageTo(name):
    for _ in range(80):
        if UiUtil.getPackageName() == name:
            return
        if "internal.app" in UiUtil.getPackageName():
            btn = TextView(text="微信", viewId="android:id/text1")
            if btn.exist():
                btn.click()
        time.sleep(0.1)
    raise Exception("无法获取到微信界面")

def gotoMainActivity():
    name = "com.tencent.mm"
    weChatIcon = TextView(text="通讯录", viewId="com.tencent.mm:id/icon_tv")
    for i in range(10):
        if weChatIcon.exist(timeout=0.1, wait=0.1):
            break
        if UiUtil.getPackageName() != name:
            UiUtil.startApp(name,"com.tencent.mm.ui.LauncherUI")
            waitForPackageTo(name)
            continue
        UiUtil.performGlobalAction(AutoService.GLOBAL_ACTION_BACK)
    if not weChatIcon.exist():
        raise Exception("打开微信异常")

def startWeChat():
    name = "com.tencent.mm"
    if UiUtil.getPackageName() == name:
        return
    UiUtil.startApp(name,"com.tencent.mm.ui.LauncherUI")
    waitForPackageTo(name)
    gotoMainActivity()

def checkPersonExist(wait=0.2):
    for _ in range(30):
        lxrIcon = TextView(text="联系人", viewId="com.tencent.mm:id/gzf")
        zcsyIcon = TextView(text="最常使用", viewId="com.tencent.mm:id/gzf")
        if lxrIcon.exist(0, wait) or zcsyIcon.exist(0, wait):
            return True
        time.sleep(0.1)
    raise Exception("用户不存在")

def sendMessage(to, msg):
    Log.log("Start wechat app...")
    startWeChat()

    Log.log("点击搜索按钮")
    searchIcon = RelativeLayout(viewId="com.tencent.mm:id/jha")
    searchIcon.click(timeout=10)
    Log.log("设置搜索内容")
    searchEdit = EditText(viewId="com.tencent.mm:id/d98")
    searchEdit.setText(to)
    checkPersonExist()
    Log.log("点击联系人")
    person = TextView(text=to, viewId="com.tencent.mm:id/odf")
    person.click()
    Log.log("设置发送内容")
    msgEdit = EditText(viewId="com.tencent.mm:id/bkk")
    msgEdit.setText(msg)
    msgEdit.click()
    Log.log("点击发送按钮")
    senBtn = Button(text="发送")
    senBtn.click(timeout=5)
    time.sleep(1)

def sendEmoji(to, emoji):
    Log.log("Start wechat app...")
    startWeChat()

    Log.log("点击搜索按钮")
    searchIcon = RelativeLayout(viewId="com.tencent.mm:id/jha")
    searchIcon.click()
    Log.log("设置搜索内容")
    searchEdit = EditText(viewId="com.tencent.mm:id/d98")
    searchEdit.setText(to)
    checkPersonExist()
    Log.log("点击联系人")
    person = TextView(text=to, viewId="com.tencent.mm:id/odf")
    person.click(gesture=False)
    Log.log("设置发送内容")
    msgEdit = ImageButton(description="表情")
    msgEdit.click()

    msgEdit = ImageView(description=emoji)
    # msgEdit = ImageView(description=emoji, viewId="com.tencent.mm:id/a50")
    msgEdit.click()
    # msgEdit = EditText(viewId="com.tencent.mm:id/bkk")
    # msgEdit.click()
    senBtn = Button(text="发送")
    senBtn.click(timeout=5, wait=1)

def addFriend(who):
    Log.log("started")
    startWeChat()
    btn = RelativeLayout(text=None, description="搜索", viewId="com.tencent.mm:id/jha")
    btn.click()
    edit=EditText(description=None, viewId="com.tencent.mm:id/d98")
    edit.setText(who)
    btn = TextView(text="查找手机/QQ号:", description=None, viewId="com.tencent.mm:id/mdq")
    btn.click(wait=2)

def checkStopSend():
    currentDir = os.path.dirname(__file__)
    fileName = os.path.join(currentDir, "stopSendWeChat")
    if os.path.exists(fileName):
        Log.log("stopSendWeChat")
        exit()

def getNextTime():
    nextTimerStamp = time.time() + random.randint(1200, 1800)
    next = time.localtime(nextTimerStamp)
    while next.tm_hour > 20 or next.tm_hour < 8:
        nextTimerStamp = nextTimerStamp + random.randint(1200, 1800)
        next = time.localtime(nextTimerStamp)
    Log.log(f"Next({int(nextTimerStamp - time.time())}): "+ time.strftime('%Y-%m-%d %H:%M:%S', next))
    return int(nextTimerStamp - time.time())


def task(t=None):
    if t is not None:
        try:
            checkStopSend()
            Log.log(f"send emoji {t}.......")
            unlockScreen()
            emoji = ["[微笑]", "[撇嘴]", "[色]", "[发呆]"]
            sendEmoji("周荣焕", random.choice(emoji))
            # addFriend("13777458099")
            Log.log("send emoji finished.......")
        except Exception as e:
            Log.log(str(e))
            return
    UiUtil.startApp("com.xiaoyuan.weHelper","com.xiaoyuan.weHelper.MainActivity")

    duaration = getNextTime()
    timeId = Timer.start(duaration, task, "wechat")
    Log.log(f"start time {timeId} for send emojo, duaration : {duaration} .....")

ThreadTask.run(task)


