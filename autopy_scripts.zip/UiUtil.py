from android.os import Bundle
from android.content import ComponentName
from android.content import Intent
from android.view.accessibility import AccessibilityNodeInfo
from android.view import ViewConfiguration
from android.accessibilityservice import GestureDescription
from android.graphics import Path
from com.chaquo.python import Python
from com.xiaoyuan.weHelper import AutoService
from android.graphics import Rect
from android.os import Build
from Log import Log, Logger
import time
import os

def logfile():
    script_dir = os.path.split(os.path.realpath(__file__))[0]
    return os.path.join(script_dir, "recode.log")

# local log
llog = Logger(logfile())


class UiUtil:
    def waitFor(conditon, timeout=5):
        endTime = time.time() + timeout
        while not conditon():
            if endTime < time.time():
                raise Exception("Wait failed!")
            time.sleep(0.1)

    def performGlobalAction(action):
        AutoService.getInstance().performGlobalAction(action)

    def getApplication():
        return Python.getInstance().getPlatform().getApplication()

    def startService(cls):
        intent = Intent(UiUtil.getApplication(), cls.getClass())
        UiUtil.getApplication().startService(intent)

    def stopService(cls):
        intent = Intent(UiUtil.getApplication(), cls.getClass())
        UiUtil.getApplication().stopService(intent)

    def click(x, y, x1=None, y1=None, duration=1, wait=0):
        time.sleep(0.01)
        path = Path()
        path.moveTo(x, y)
        if x1 is None:
            path.lineTo(x, y)
        else:
            path.lineTo(x1, y1)
        builder = GestureDescription.Builder()
        builder.addStroke(GestureDescription.StrokeDescription(path, 0, duration))
        gesture = builder.build()
        AutoService.getInstance().dispatchGesture(gesture, None, None)
        time.sleep(wait)

    def startApp(pkg, cls):
        intent = Intent()
        componentName = ComponentName(pkg, cls)
        intent.setAction(Intent.ACTION_MAIN)
        intent.addCategory(Intent.CATEGORY_LAUNCHER)
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        intent.setComponent(componentName)
        UiUtil.getApplication().startActivity(intent)

    def getRootNode():
        if not AutoService.isConnected():
            Log.log("Accessibility Server is stoped!!")
            return None
        return AutoService.getInstance().getRootInActiveWindow()

    def getPackageName():
        node = UiUtil.getRootNode()
        return node.getPackageName() if node else ""

    def getBoundsInScreen(node):
        rect = Rect()
        node.getBoundsInScreen(rect)
        return rect

    def findNode(rootNode, refresh, comfunc):
        if rootNode is None:
            return None
        if refresh:
            rootNode.refresh()
        if comfunc(rootNode):
            return rootNode
        for i in range(rootNode.getChildCount()):
            node = UiUtil.findNode(rootNode.getChild(i), refresh, comfunc)
            if node:
                return node
        return None

    def findNodes(rootNode, refresh, comfunc, *args, **kwargs):
        nodes = []
        if rootNode is None:
            return nodes
        if refresh:
            rootNode.refresh()
        if comfunc(rootNode, *args, **kwargs):
            nodes.append(rootNode)
        for i in range(rootNode.getChildCount()):
            subnodes = UiUtil.findNodes(
                rootNode.getChild(i), refresh, comfunc, args, kwargs)
            nodes.extend(subnodes)
        return nodes

    def checkNode(node, className, text, description, viewId):
        if text is not None and text not in str(node.getText()):
            return False
        if viewId is not None and viewId not in str(node.getViewIdResourceName()):
            return False
        if className is not None and className not in str(node.getClassName()):
            return False
        if description is not None and description not in str(node.getContentDescription()):
            return False
        return True


class NoneUIControl:
    def __init__(self, rootNode=None, className=None, text=None, description=None, viewId=None, item=None, nodeCondition=None):
        pass

    def exist(self, timeout=5, wait=0, reget=False):
        return False

    def waitDisappear(self, timeout=5, wait=0):
        Log.log("NoneUIControl is not support: waitDisappear")
        return True

    def equals(self, nodeUi):
        return False

    def getText(self):
        Log.log("NoneUIControl is not support: getText")
        return ""

    def getClassName(self):
        Log.log("NoneUIControl is not support: getClassName")
        return ""

    def getDescription(self):
        Log.log("NoneUIControl is not support: getDescription")
        return ""

    def getParent(self, timeout=5):
        Log.log("NoneUIControl is not support: getParent")
        return NoneUIControl()

    def getChildCount(self, timeout=5):
        Log.log("NoneUIControl is not support: getChildCount")
        return 0

    def getChild(self, i, timeout=5):
        Log.log("NoneUIControl is not support: ")
        return NoneUIControl()

    def setText(self, text, timeout=5, wait=0.3):
        Log.log("NoneUIControl is not support: setText")

    def longClick(self, timeout=5, wait=0.3, gesture=False):
        Log.log("NoneUIControl is not support: longClick")

    def click(self, timeout=5, wait=0.3, gesture=False, duration=1):
        Log.log("NoneUIControl is not support: click")

    def show(self, prei="", timeout=5):
        Log.log("NoneUIControl is not support: show")

    def getRect(self, timeout=5):
        Log.log("NoneUIControl is not support: getRect")
        return Rect()


class UIControl:
    def __init__(self, rootNode=None, className=None, text=None, description=None, viewId=None, item=None, nodeCondition=None):
        self.item = item
        self.className = className
        self.rootNode = rootNode
        self.text = text
        self.description = description
        self.viewId = viewId
        self.nodeCondition = nodeCondition
        self.rect = None

    def exist(self, timeout=5, wait=0, reget=False):
        if reget:
            self.rootNode = None
        if self._getNode(timeout=timeout, reget=reget):
            time.sleep(wait)
        return self.item is not None

    def waitDisappear(self, timeout=5, wait=0):
        startTime = time.time()
        while self._getNode(True, 0):
            if time.time()-startTime > timeout:
                return False
            time.sleep(0.1)
        time.sleep(wait)
        return True

    def equals(self, nodeUi):
        if self.item is None:
            return False
        if nodeUi is None:
            return False
        return self.item.equals(nodeUi)

    def getText(self):
        node = self._getNode(timeout=0)
        if node is None:
            return ""
        text = node.getText()
        if text is None:
            return ""
        return str(text)

    def getClassName(self):
        if self.className is None:
            return ""
        return str(self.className)

    def getDescription(self):
        node = self._getNode(timeout=0)
        if node is None:
            return ""
        desc = node.getContentDescription()
        if desc is None:
            return ""
        return str(desc)

    def getParent(self, timeout=5):
        node = self._getNode(timeout=timeout)
        if node is None:
            return NoneUIControl()
        parent = node.getParent()
        className = parent.getClassName().split(".")[-1]
        return UIControl(None, className, parent.getText(), parent.getContentDescription(), parent.getViewIdResourceName(), item=parent)

    def getChildCount(self, timeout=5):
        node = self._getNode(timeout=timeout)
        if node is None:
            return 0
        return node.getChildCount()

    def getChild(self, i, timeout=5):
        node = self._getNode(timeout=timeout)
        if node is None:
            return NoneUIControl()
        if self.getChildCount(0) <= i:
            return NoneUIControl()
        child = node.getChild(i)
        if child is None:
            return NoneUIControl()
        className = child.getClassName().split(".")[-1]
        return UIControl(self, className, child.getText(), child.getContentDescription(), child.getViewIdResourceName(), item=child)

    def setText(self, text, timeout=5, wait=0.3):
        node = self._getNode(timeout=timeout)
        if node is None:
            raise Exception(f"node({self.className} {self.text} {self.viewId}) not exist")
        arguments = Bundle()
        arguments.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,text)
        node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT,arguments)
        time.sleep(wait)

    def longClick(self, timeout=5, wait=0.3, gesture=False):
        node = self._getNode(timeout=timeout)
        if node is None:
            raise Exception(f"node({self.className} {self.text} {self.viewId}) not exist")
        if Build.VERSION.SDK_INT >= Build.VERSION_CODES.N and gesture:
            rect = self.getRect()
            UiUtil.click(rect.centerX(), rect.centerY(), duration=ViewConfiguration.getLongPressTimeout()*2, wait=wait)
            return
        while node and not node.isLongClickable():
            node = node.getParent()
        if node is None:
            Log.log("not Click able")
            return
        node.performAction(AccessibilityNodeInfo.ACTION_LONG_CLICK)
        time.sleep(wait)

    def click(self, timeout=5, wait=0.3, gesture=False, duration=1):
        node = self._getNode(timeout=timeout)
        if node is None:
            raise Exception(f"node({self.className} {self.text} {self.viewId}) not exist")
        if Build.VERSION.SDK_INT >= Build.VERSION_CODES.N and gesture:
            rect = self.getRect()
            UiUtil.click(rect.centerX(), rect.centerY(), duration=duration, wait=wait)
            return
        while node and not node.isClickable():
            node = node.getParent()
        if node is None:
            return
        node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        time.sleep(wait)

    def scrollForward(self, timeout=5, wait=0.3):
        node = self._getNode(timeout=timeout)
        if node is None:
            raise Exception(f"node({self.className} {self.text} {self.viewId}) not exist")
        node.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)
        time.sleep(wait)

    def show(self, prei="", timeout=5):
        node = self._getNode(timeout=timeout)
        if node is None:
            return
        Log.log(f"{prei}{self.getClassName()} {self.getText()} {self.getDescription()} {self.getRect()} {self.viewId}")
        for i in range(self.getChildCount()):
            self.getChild(i).show(prei+"  ")

    def getRect(self, timeout=5):
        node = self._getNode(timeout=timeout)
        if node is None:
            return Rect()
        self.rect = UiUtil.getBoundsInScreen(node)
        return self.rect

    def _getNode(self, reget=False, timeout=5):
        if self.item and not reget:
            return self.item
        self.item = None
        starttime = time.time()
        refresh = False
        while self.item is None:
            if self.rootNode is None:
                node = AutoService.getInstance().getRootInActiveWindow()
            else:
                node = self.rootNode._getNode(reget=reget, timeout=timeout)
            self.item = UiUtil.findNode(node, refresh, self._nodeCmpFunc)
            if starttime + timeout > time.time() or (not refresh and timeout > 0.001):
                time.sleep(0.001)
                refresh = True
                continue
            break
        if self.item:
            self.getRect()
        return self.item

    def _nodeCmpFunc(self, node):
        if self.text is not None and self.text not in str(node.getText()):
            return False
        if self.viewId is not None and self.viewId not in str(node.getViewIdResourceName()):
            return False
        if self.className is not None and self.className not in str(node.getClassName()):
            return False
        if self.description is not None and self.description not in str(node.getContentDescription()):
            return False
        if self.rect is not None:
            rect = UiUtil.getBoundsInScreen(node)
            if self.rect.width() != rect.width() or self.rect.height() != rect.height():
                return False
        if self.nodeCondition is not None:
            if not self.nodeCondition(node):
                return False
        return True

    def View(self, text=None, description=None, viewId=None, item=None, nodeCondition=None):
        return View(self, text, description, viewId, item, nodeCondition)

    def EditText(self, text=None, description=None, viewId=None, item=None, nodeCondition=None):
        return EditText(self, text, description, viewId, item, nodeCondition)

    def RelativeLayout(self, text=None, description=None, viewId=None, item=None, nodeCondition=None):
        return RelativeLayout(self, text, description, viewId, item, nodeCondition)

    def TextView(self, text=None, description=None, viewId=None, item=None, nodeCondition=None):
        return TextView(self, text, description, viewId, item, nodeCondition)

    def Button(self, text=None, description=None, viewId=None, item=None, nodeCondition=None):
        return Button(self, text, description, viewId, item, nodeCondition)

    def ImageButton(self, text=None, description=None, viewId=None, item=None, nodeCondition=None):
        return ImageButton(self, text, description, viewId, item, nodeCondition)

    def ImageView(self, text=None, description=None, viewId=None, item=None, nodeCondition=None):
        return ImageView(self, text, description, viewId, item, nodeCondition)

    def ViewGroup(self, text=None, description=None, viewId=None, item=None, nodeCondition=None):
        return ViewGroup(self, text, description, viewId, item, nodeCondition)

    def RecyclerView(self, text=None, description=None, viewId=None, item=None, nodeCondition=None):
        return RecyclerView(self, text, description, viewId, item, nodeCondition)

    def FrameLayout(self, text=None, description=None, viewId=None, item=None, nodeCondition=None):
        return FrameLayout(self, text, description, viewId, item, nodeCondition)

    def ListView(self, text=None, description=None, viewId=None, item=None, nodeCondition=None):
        return ListView(self, text, description, viewId, item, nodeCondition)

    def CheckBox(self, text=None, description=None, viewId=None, item=None, nodeCondition=None):
        return CheckBox(self, text, description, viewId, item, nodeCondition)


class View(UIControl):
    def __init__(self, rootNode=None, text=None, description=None, viewId=None, item=None, nodeCondition=None):
        super().__init__(rootNode, "View", text, description, viewId, item, nodeCondition)

class EditText(UIControl):
    def __init__(self, rootNode=None, text=None, description=None, viewId=None, item=None, nodeCondition=None):
        super().__init__(rootNode, "EditText", text, description, viewId, item, nodeCondition)

class RelativeLayout(UIControl):
    def __init__(self, rootNode=None, text=None, description=None, viewId=None, item=None, nodeCondition=None):
        super().__init__(rootNode, "RelativeLayout", text, description, viewId, item, nodeCondition)

class TextView(UIControl):
    def __init__(self, rootNode=None, text=None, description=None, viewId=None, item=None, nodeCondition=None):
        super().__init__(rootNode, "TextView", text, description, viewId, item, nodeCondition)

class Button(UIControl):
    def __init__(self, rootNode=None, text=None, description=None, viewId=None, item=None, nodeCondition=None):
        super().__init__(rootNode, "Button", text, description, viewId, item, nodeCondition)

class ImageButton(UIControl):
    def __init__(self, rootNode=None, text=None, description=None, viewId=None, item=None, nodeCondition=None):
        super().__init__(rootNode, "ImageButton", text, description, viewId, item, nodeCondition)

class ImageView(UIControl):
    def __init__(self, rootNode=None, text=None, description=None, viewId=None, item=None, nodeCondition=None):
        super().__init__(rootNode, "ImageView", text, description, viewId, item, nodeCondition)

class ViewGroup(UIControl):
    def __init__(self, rootNode=None, text=None, description=None, viewId=None, item=None, nodeCondition=None):
        super().__init__(rootNode, "ViewGroup", text, description, viewId, item, nodeCondition)

class RecyclerView(UIControl):
    def __init__(self, rootNode=None, text=None, description=None, viewId=None, item=None, nodeCondition=None):
        super().__init__(rootNode, "RecyclerView", text, description, viewId, item, nodeCondition)

class FrameLayout(UIControl):
    def __init__(self, rootNode=None, text=None, description=None, viewId=None, item=None, nodeCondition=None):
        super().__init__(rootNode, "FrameLayout", text, description, viewId, item, nodeCondition)

class ListView(UIControl):
    def __init__(self, rootNode=None, text=None, description=None, viewId=None, item=None, nodeCondition=None):
        super().__init__(rootNode, "ListView", text, description, viewId, item, nodeCondition)

class CheckBox(UIControl):
    def __init__(self, rootNode=None, text=None, description=None, viewId=None, item=None, nodeCondition=None):
        super().__init__(rootNode, "CheckBox", text, description, viewId, item, nodeCondition)
