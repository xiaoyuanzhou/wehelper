import os
import queue
from android.os import FileObserver
from _JavaProxy import JavaProxy

@JavaProxy(FileObserver)
class PyFileObserver:
    def __init__(self, monitorDir, condition) -> None:
        self.monitorDir = monitorDir
        self.condition = condition
        self.notify = queue.Queue()
        self.name = None

    def wait(self, timeout=20):
        for i in range(int(timeout*10)):
            try:
                self.notify.get(timeout=0.1)
                return True
            except queue.Empty as e:
                pass
        return False

    def onEvent(self, type, name):
        if self.condition(type, name):
            if self.name is None:
                self.name = os.path.join(self.monitorDir, name)
            self.notify.put(1)
