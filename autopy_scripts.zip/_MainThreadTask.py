from android.os import Handler
from android.os import Looper
from java.lang import Runnable
from java import dynamic_proxy
import queue
import traceback
from Log import Log


class RunnableTask(dynamic_proxy(Runnable)):
    def __init__(self, task):
        super().__init__()
        self.task = task

    def run(self):
        self.task()


class MainThreadTask:
    def __init__(self) -> None:
        self.handler = Handler(Looper.getMainLooper())
        self.finishQ = queue.Queue()
    
    def wait(self):
        while True:
            try:
                self.finishQ.get(timeout=0.01)
                break
            except queue.Empty as _:
                pass

    def run(self, task, *args, **kwargs):
        def _task():
            try:
                task(*args, **kwargs)
            except Exception as e:
                Log.log(str(traceback.format_exc()))
            finally:
                self.finishQ.put(1)
        if Looper.myLooper() == Looper.getMainLooper():
            _task()
        else:
            self.handler.postAtFrontOfQueue(RunnableTask(_task))
        return self

