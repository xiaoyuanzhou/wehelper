import traceback
import os,sys
import importlib
from android.os import Handler
from java.lang import Runnable
from java import dynamic_proxy
from _global import G
from Log import Log


class FileTask(dynamic_proxy(Runnable)):
    def __init__(self, taskId, currentDir, fileName):
        super().__init__()
        self.currentDir = currentDir
        self.fileName = fileName
        self.taskId = taskId

    def run(self):
        if self.taskId != G().fileTaskId:
            Log.log(f"File task {self.taskId} stoped")
            return
        if not os.path.exists(self.fileName):
            Handler().postDelayed(FileTask(self.taskId, self.currentDir, self.fileName), 100)
            return
        try:
            sys.path.append(self.currentDir)
            module = importlib.import_module("_")
            sys.modules.pop("_")
            del module
        except Exception as e:
            Log.log(str(traceback.format_exc()))
        finally:
            os.remove(self.fileName)
            Handler().postDelayed(FileTask(self.taskId, self.currentDir, self.fileName), 100)

if G().fileTaskId is None:
    G().fileTaskId = 1
else:
    G().fileTaskId += 1

currentDir = os.path.dirname(__file__)
fileName = os.path.join(currentDir, "_.py")
Log.log(f"File task {G().fileTaskId} start")
Handler().postDelayed(FileTask(G().fileTaskId, currentDir, fileName), 100)


