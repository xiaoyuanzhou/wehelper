import threading
from android.view.accessibility import AccessibilityEvent
from Log import Log
from _UiUtil import UiUtil
from _weMoments import Moments
from _TopCloneMomentsMenu import TopCloneMomentsMenu
from _LastActivity import LastActivity

class PersonMomentsHandler:
    def __init__(self) -> None:
        self.currentFromIndex = None
        self.currentToIndex = None
        self.lastEventTime = 0
        self.lock = threading.Lock()
        self.curMoments = Moments()
        self.moments = Moments()
        self.menu = TopCloneMomentsMenu(UiUtil.getApplication(), self.moments, None)
        self.packageName = "com.tencent.mm"
        self.activity = ".SnsUserUI"

    def getMomentsInScreen(self, ind, winRect):
        with self.lock:
            for moment in self.curMoments.moments:
                if moment.ind != ind:
                    continue
                rect = moment.right.getRect()
                finded = winRect.contains(rect.centerX(), rect.centerY())
                if finded:
                    return moment
                return None
        return None

    def handle(self, event, queue):
        if not self.isInSnsUserUI():
            self.moments.clean()
            self.menu.hide()
            return
        if not self._isMmEvent(event):
            return
        if not self.menu.isShowed():
            self.menu.show()
        self.reset()
        moments = None
        personMementsEvents = self.getEvents(event, queue)
        while self.hasValidEvents(personMementsEvents):
            self.setLastEventTime(personMementsEvents)
            moments = Moments()
            moments.getPersonMoments(self.currentFromIndex, self.currentToIndex)
            if not self.isInSnsUserUI():
                self.moments.clean()
                self.menu.hide()
                return
            personMementsEvents = self.getEvents(None, queue)
        self.updateMoments(moments)

    def isInSnsUserUI(self):
        return self._isCurrentIn(self.packageName, self.activity)

    def isInSnsCommentDetailUI(self):
        return self._isCurrentIn(self.packageName, ".SnsCommentDetailUI")

    def _isCurrentIn(self, packageName, activity):
        if packageName not in UiUtil.getPackageName():
            return False
        return activity in LastActivity.getActivity(packageName)

    def cleanMoments(self):
        with self.lock:
            self.curMoments.clean()
            self.moments.clean()

    def updateMoments(self, moments):
        with self.lock:
            if moments is None:
                self.curMoments.clean()
                return
            self.curMoments = moments
            self.moments.addMemonts(moments.moments)
            self.moments.person = moments.person

    def reset(self):
        self.currentFromIndex = None
        self.currentToIndex = None
    
    def getEvents(self, event, queue):
        personMementsEvents = list(filter(self._isMmEvent, queue.queue))
        reEvent = [e[0] for e in personMementsEvents]
        if self._isMmEvent(event):
            reEvent.insert(0, event)
        return reEvent
    
    def _isMmEvent(self, inEvent):
        event = inEvent
        if isinstance(inEvent, tuple):
            event = inEvent[0]
        if event is None:
            return False
        if event.getEventTime() <= self.lastEventTime or self.packageName != event.getPackageName():
            return False
        return event.getEventType() == AccessibilityEvent.TYPE_VIEW_SCROLLED or event.getEventType() == AccessibilityEvent.TYPE_VIEW_SCROLLED

    def hasValidEvents(self, events):
        for event in events:
            if event.getEventType() == AccessibilityEvent.TYPE_VIEW_SCROLLED and event.getFromIndex() >= 0:
                self.currentFromIndex = event.getFromIndex()
                self.currentToIndex = event.getToIndex()
        return len(events) > 0 and self.currentFromIndex is not None

    def setLastEventTime(self, events):
        self.lastEventTime = events[-1].getEventTime()


personMomentsHandler = PersonMomentsHandler()
