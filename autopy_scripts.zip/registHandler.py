from com.xiaoyuan.weHelper import AutoService
from Log import Log
from UiUtil import llog
from _WindowManager import WindowManagerHelper

# AutoService.getInstance().registerHandler("_event_handle", "handle")
WindowManagerHelper.removeAll()
AutoService.getInstance().registerHandler("weFriends", "handle")
Log.log("RegisterHandler Success!!!!!")
llog.log("RegisterHandler Success!!!!!")
llog.log("=="*25)
