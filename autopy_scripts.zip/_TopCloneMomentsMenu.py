from android.os import Build
from android.graphics import PixelFormat
from android.view import MotionEvent
from android.view import View
from android.view import Gravity
from android.view import WindowManager
from android.widget import TextView, LinearLayout
from com.xiaoyuan.weHelper import AutoService
from android.view import ViewConfiguration
from Log import Log
from _UiUtil import UiUtil
from _MainThreadTask import MainThreadTask
from _ConcreteClickProxy import OnTouchListenerProxy

from android.graphics import Color
import importlib
importlib.reload(importlib.import_module("_TopDialog"))
from _TopDialog import TopDialog
from _WindowManager import WindowManagerHelper


class TopDialogListItem:
    def __init__(self, title, ind):
        self.title = title
        self.isChecked = False
        self.ind = ind


class TouchHelp:
    def __init__(self, param, view, parent) -> None:
        self.touchSlop = ViewConfiguration.get(
            AutoService.getInstance()).getScaledTouchSlop()
        self.begin = None
        self.end = None
        self.param = None
        self.layoutParams = param
        self.view = view
        self.parent = parent
        self.handled = False

    def onClick(self):
        topDialogListItems = []
        preReleaseDate = ""
        for moment in self.parent.moments.moments:
            releaseDate = moment.releaseDate
            if releaseDate != "":
                preReleaseDate = releaseDate
            text = "=============\n第"+str(moment.ind-1) + "条: " + preReleaseDate + " | " + moment.releaseType + "\n------------\n" + moment.releaseText
            # Log.log(moment.personMomentGetType())
            topDialogListItems.append(TopDialogListItem(text, moment.ind))
        dia = TopDialog(self.parent.moments.person, self.parent.cloneFunc)
        dia.setMenu(topDialogListItems)
        dia.show()

    def isMove(self):
        if self.end is None:
            return False
        if abs(self.begin[0]-self.end[0]) > self.touchSlop:
            return True
        if abs(self.begin[1]-self.end[1]) > self.touchSlop:
            return True
        return False

    def onTouch(self, event):
        if event.getAction() == MotionEvent.ACTION_DOWN:
            self.begin = (event.getRawX(), event.getRawY())
            self.param = (self.layoutParams.x, self.layoutParams.y)
            self.handled = False
        elif event.getAction() == MotionEvent.ACTION_MOVE:
            self.end = (event.getRawX(), event.getRawY())
            if self.isMove():
                self.layoutParams.x = int(self.param[0] - self.begin[0] + self.end[0])
                self.layoutParams.y = int(self.param[1] + self.begin[1] - self.end[1])
                WindowManagerHelper.updateViewLayout(self.view, self.layoutParams)
                self.parent.x = self.layoutParams.x
                self.parent.y = self.layoutParams.y
                self.handled = True
        elif event.getAction() ==  MotionEvent.ACTION_UP:
            if self.handled:
                return True
            if event.getEventTime() - event.getDownTime() >= ViewConfiguration.getLongPressTimeout():
                return True
            if self.onClick:
                self.onClick()
        return True


class TopCloneMomentsMenu:
    def __init__(self, context, moments, cloneFunc) -> None:
        self.context = context
        self.moments = moments
        self.menuView = None
        self.touchHelper = None
        self.x = None
        self.y = None
        self.cloneFunc = cloneFunc

    def __del__(self) -> None:
        self.hide()

    def isShowed(self):
        return self.menuView is not None

    def show(self):
        if self.x is None:
            root = AutoService.getInstance().getRootInActiveWindow()
            if root is None:
                self.x = 800
                self.y = 300
            else:
                winRect = UiUtil.getBoundsInScreen(root)
                self.x = winRect.right
                self.y = winRect.bottom - int(winRect.height() / 2)
        MainThreadTask().run(self._show, self.x, self.y).wait()

    def _show(self, x, y):
        if self.menuView is not None:
            self._hide()
            return
        self._createView()
        layoutParams = self._createLayoutParams(x, y)
        WindowManagerHelper.addView(self.menuView, layoutParams)
        self.touchHelper = TouchHelp(layoutParams, self.menuView, self)

    def hide(self):
        if self.menuView is None:
            return
        MainThreadTask().run(self._hide).wait()

    def _hide(self):
        if self.menuView is None:
            return
        WindowManagerHelper.removeView(self.menuView)
        self.menuView = None

    def onClick(self, event):
        if self.touchHelper is None:
            return False
        return self.touchHelper.onTouch(event)

    def _createView(self):
        self.menuView = LinearLayout(AutoService.getInstance())
        self.menuView.setBackgroundColor(Color.BLUE)
        self.menuView.setOnTouchListener(
            OnTouchListenerProxy(self.onClick))

        clone = TextView(AutoService.getInstance())
        clone.setId(View.generateViewId())
        clone.setText("克隆")
        clone.setTextSize(24)
        clone.setLayoutParams(LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        self.menuView.addView(clone)

    def _createLayoutParams(self, x, y):
        layoutParams = WindowManager.LayoutParams()
        layoutParams.x = x
        layoutParams.y = y
        layoutParams.width = WindowManager.LayoutParams.WRAP_CONTENT
        layoutParams.height = WindowManager.LayoutParams.WRAP_CONTENT
        layoutParams.flags = (WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                            | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                            | WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH
                            | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN)
        layoutParams.format = PixelFormat.RGBA_8888
        layoutParams.gravity = Gravity.LEFT | Gravity.BOTTOM
        if Build.VERSION.SDK_INT >= 26: #Build.VERSION_CODES.O
            layoutParams.type = WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY
        else:
            layoutParams.type = WindowManager.LayoutParams.TYPE_TOAST
        return layoutParams
