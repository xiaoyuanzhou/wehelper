from java import dynamic_proxy
from android.view import View
from android.widget import AdapterView

class OnClickListenerProxy(dynamic_proxy(View.OnClickListener)):
    def __init__(self, actionHandler):
        super().__init__()
        self.actionHandler = actionHandler

    def onClick(self, view):
        self.actionHandler(view)


class OnTouchListenerProxy(dynamic_proxy(View.OnTouchListener)):
    def __init__(self, actionHandler):
        super().__init__()
        self.actionHandler = actionHandler

    def onTouch(self, view, event):
        return self.actionHandler(event)


class OnItemClickListenerProxy(dynamic_proxy(AdapterView.OnItemClickListener)):
    def __init__(self, actionHandler):
        super().__init__()
        self.actionHandler = actionHandler

    def onItemClick(self, parent, view, position, id):
        self.actionHandler(position)

