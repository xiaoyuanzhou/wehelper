import importlib
import traceback
import time
import os
import json
from android.os import Environment
from _UiUtil import (UiUtil, UIControl, RecyclerView, 
                    ListView, ImageView, TextView,
                    View, ViewGroup, EditText,
                    RelativeLayout, Button)
from _WechatUIHelper import WechatUIHelper
from _MediaObserver import MediaObserver
from Log import Log


class NodeHelp:
    @staticmethod
    def getText(node):
        text = ""
        if node.getText() != "":
            text = node.getText() + " "
        for i in range(node.getChildCount()):
            subText = NodeHelp.getText(node.getChild(i))
            if subText != "":
                text += subText + " "
        return text

    @staticmethod
    def getDescription(node):
        text = ""
        if node.getDescription() != "":
            text += node.getDescription() + " "
        for i in range(node.getChildCount()):
            subText = NodeHelp.getDescription(node.getChild(i))
            if subText != "":
                text += subText + " "
        return text

    @staticmethod
    def toDict(node, onlyCls=False):
        ret = {}
        ret["cls"] = node.getClassName()
        if not onlyCls:
            ret["text"] = str(node.getText())
            ret["desc"] = str(node.getDescription())
        if node.getChildCount() == 0:
            return ret
        ret["childs"] = []
        for i in range(node.getChildCount()):
            ret["childs"].append(NodeHelp.toDict(node.getChild(i), onlyCls))
        return ret

    @staticmethod
    def toJson(node, onlyCls=False, indent=None):
        d = NodeHelp.toDict(node, onlyCls=onlyCls)
        return json.dumps(d, ensure_ascii=False, indent=indent)


def getWeiXinDir():
    dir = Environment.getExternalStorageDirectory().toString()
    return os.path.join(dir, "Pictures/WeiXin")


class MomentForwardHelp:
    def forward(moment, autosend=False):
        try:
            if moment.pictureGroup is not None or moment.picture is not None:
                PictureGroupMomentForwardHelp(moment).forward(autosend)
            elif moment.video is not None:
                VideoMomentForwardHelp(moment).forward(autosend)
            elif moment.text is not None:
                TextMomentForwardHelp(moment).forward(autosend)
            else:
                Log.log("Not support forward this moment, due to all info is empty()")
        except Exception as e:
            Log.log(str(traceback.format_exc()))
            Log.log(str(e))


class VideoMomentForwardHelp:
    def __init__(self, moment) -> None:
        self.moment = moment
        self.exportPics = []
        self.obs = None

    def startWatchingForFileExport(self):
        self.obs = MediaObserver.monitor(MediaObserver.Video)

    def waitForFileExport(self):
        ret = self.obs.wait(100)
        self.obs.stop()
        return ret

    def removeExprotFiles(self):
        for pic in self.exportPics:
            Log.log(f"remove file {pic}")
            os.remove(pic)

    def saveVideo(self):
        self.moment.video.exist()
        self.moment.video.longClick(gesture=True)
        TextView(text="静音播放").click()
        self.moment.video.waitDisappear(wait=0.3)
        self.startWatchingForFileExport()
        seccussed=False
        for i in range(3):
            try:
                RelativeLayout(description="视频").longClick(gesture=True)
                TextView(text="保存视频").click(timeout=1, wait=0)
                TextView(text="保存视频").waitDisappear(wait=0)
                seccussed = True
                break
            except:
                pass
        if seccussed:
            Log.log("waitForFileExport")
            seccussed = self.waitForFileExport()
        if not seccussed:
            Log.log("转发朋友圈失败...., 无法保存图片")
            self.obs.stopWatching()
            self.removeExprotFiles()
            return False
        RelativeLayout(description="视频").click(gesture=True, duration=10)
        self.moment.video.exist(reget=True)
        return True

    def forward(self, autosend):
        text = self.moment.text.getText() if self.moment.text is not None else None
        if not self.saveVideo():
            return

        momentBtn = ImageView(description="拍照分享")
        if not momentBtn.exist(timeout=0):
            WechatUIHelper.gotoMainUi()
            WechatUIHelper.gotoSelfMoments()
        momentBtn.click(wait=0)
        selectBtn = TextView(text="从相册选择")
        checkStartTime = time.time()
        while not selectBtn.exist(timeout=0):
            if Button(text="发表").exist(timeout=0):
                Log.log("有保留的代发表朋友圈，请先清除....")
                return
            if time.time() - checkStartTime > 5:
                Log.log("获取 从相册选择 按钮 异常....")
                return
            time.sleep(0.1)
        selectBtn.click()
        image = ImageView(description="视频1").getParent()
        image.CheckBox().click()

        Button(text="完成", nodeCondition=lambda node: node.isClickable()).exist()
        while not Button(text="发表").exist(timeout=0.1):
            fi = Button(text="完成", nodeCondition=lambda node: node.isClickable())
            if fi.exist(timeout=0.1):
                fi.click()
        if text:
            EditText().setText(text)
        if autosend:
            Button(text="发表").click()
        self.removeExprotFiles()


class PictureGroupMomentForwardHelp:
    def __init__(self, moment) -> None:
        self.moment = moment
        self.exportPics = []
        self.obs = None

    def startWatchingForFileExport(self):
        self.obs = MediaObserver.monitor(MediaObserver.Images)

    def waitForFileExport(self):
        ret = self.obs.wait(10)
        self.obs.stop()
        return ret

    def removeExprotFiles(self):
        for pic in self.exportPics:
            Log.log(f"remove file {pic}")
            os.remove(pic)

    def saveImage(self, x, y, desc):
        def checkRect(node):
            rect = UiUtil.getBoundsInScreen(node)
            return x == rect.centerX() and y == rect.centerY()
        View(description=desc, nodeCondition=checkRect).exist()
        UiUtil.click(x, y, duration=10)
        image = UIControl(description="轻触两下关闭图片")
        isExist = image.exist()
        if not isExist:
            Log.log("转发朋友圈失败....")
            return
        rect = UiUtil.getBoundsInScreen(image.item)
        self.startWatchingForFileExport()
        seccussed = False
        for i in range(3):
            try:
                image.longClick(gesture=True)
                TextView(text="保存图片").click(timeout=1, wait=0)
                TextView(text="保存图片").waitDisappear(wait=0)
                seccussed = True
                break
            except:
                pass
        if seccussed:
            self.waitForFileExport()
        else:
            self.obs.stopWatching()
            self.removeExprotFiles()
            Log.log("转发朋友圈失败...., 无法保存图片")
            return
        UiUtil.click(rect.centerX(),rect.centerY(), duration=10)
        View(description=desc, nodeCondition=checkRect).exist()

    def saveImages(self):
        if self.moment.picture is not None:
            rect = UiUtil.getBoundsInScreen(self.moment.picture.item)
            self.saveImage(rect.centerX(), rect.centerY(), self.moment.picture.getDescription())
            return 1

        picCoodi = []
        for i in range(self.moment.pictureGroup.getChildCount()-1, -1, -1):
            pic = self.moment.pictureGroup.getChild(i)
            rect = UiUtil.getBoundsInScreen(pic.item)
            picCoodi.append((rect.centerX(), rect.centerY(), pic.getDescription()))
        for (x, y, desc) in picCoodi:
            self.saveImage(x, y, desc)
        return len(picCoodi)

    def forward(self, autosend):
        text = self.moment.text.getText() if self.moment.text is not None else None
        imageCount = self.saveImages()
        momentBtn = ImageView(description="拍照分享")
        if not momentBtn.exist(timeout=0):
            WechatUIHelper.gotoMainUi()
            WechatUIHelper.gotoSelfMoments()
        momentBtn.click(wait=0)
        selectBtn = TextView(text="从相册选择")
        checkStartTime = time.time()
        while not selectBtn.exist(timeout=0):
            if Button(text="发表").exist(timeout=0):
                Log.log("有保留的代发表朋友圈，请先清除....")
                return
            if time.time() - checkStartTime > 5:
                Log.log("获取 从相册选择 按钮 异常....")
                return
            time.sleep(0.1)
        selectBtn.click()
        for i in range(imageCount):
            image = ImageView(description=f"图片{i+1}").getParent()
            image.CheckBox().click()

        Button(text="完成", nodeCondition=lambda node: node.isClickable()).click()
        Button(text="发表").exist()
        if text:
            EditText().setText(text)
        if autosend:
            Button(text="发表").click()
        # self.removeExprotFiles()


class TextMomentForwardHelp:
    def __init__(self, moment) -> None:
        Log.log("TextMomentForwardHelp")
        self.moment = moment

    def forward(self, autosend):
        text = self.moment.text.getText()
        momentBtn = ImageView(description="拍照分享")
        if not momentBtn.exist(timeout=0):
            WechatUIHelper.gotoMainUi()
            WechatUIHelper.gotoSelfMoments()
        momentBtn.longClick()
        EditText(text="这一刻的想法...").setText(text)
        if autosend:
            Button(text="发表").click()


class Moment:
    def __init__(self) -> None:
        self.root = None
        self.left = None
        self.right = None
        self.name = None
        self.text = None
        self.link = None
        self.video = None
        self.pictureGroup = None
        self.picture = None
        self.shortVideo = None
        self.advertisement = None
        self.dotBtn = None
        self.address = None

    def personMomentGetDate(self):
        d = self.left.getChild(0)
        if d is None:
            return ""
        d = d.getChild(0)
        if d is None:
            return ""
        dt = NodeHelp.getText(d).strip().split(" ")
        dt.reverse()
        return "".join(dt).strip()

    def personMomentGetText(self):
        return NodeHelp.getText(self.right).strip()

    def personMomentGetType(self):
        desc = NodeHelp.getDescription(self.right).strip()
        if "包含一条小视频" in desc:
            return "小视频"
        if "包含一张图片" in desc:
            return "单图"
        if "包含多张图片" in desc:
            return "多图"
        if "的视频" in desc:
            return "短视频"
        if desc.endswith(" 图片"):
            return "链接"
        return desc

    def getSign(self, onlyCls=False):
        if self.root is None:
            return "{}"
        return NodeHelp.toJson(self.root, onlyCls)
        # return self.getNodeSign(self.root)

    def isDotBtnClicked(self, clickView):
        return self.dotBtn.equals(clickView)

    def show(self):
        text = None
        if self.text is not None:
            text = self.text.getText()
        if self.advertisement is not None:
            Log.log(f"{self.name.getText()} 发表广告, dotBtn:{self.dotBtn is not None} 文字: {text}")
        elif self.link is not None:
            Log.log(f"{self.name.getText()} 发表链接, dotBtn:{self.dotBtn is not None} 文字: {text}")
        elif self.video is not None:
            Log.log(f"{self.name.getText()} 发表视频, dotBtn:{self.dotBtn is not None} 文字: {text}")
        elif self.pictureGroup is not None:
            Log.log(f"{self.name.getText()} 发表组图, dotBtn:{self.dotBtn is not None} 文字: {text}")
        elif self.picture is not None:
            Log.log(f"{self.name.getText()} 发表图片, dotBtn:{self.dotBtn is not None} 文字: {text}")
        elif self.shortVideo is not None:
            Log.log(f"{self.name.getText()} 发表短视频, dotBtn:{self.dotBtn is not None} 文字: {text}")
        elif self.text is not None:
            Log.log(f"{self.name.getText()} 发表纯文, dotBtn:{self.dotBtn is not None} 文字: {text}")
        else:
            Log.log("未知错误")

    def getDotBtnRect(self):
        return UiUtil.getBoundsInScreen(self.dotBtn.item)

    def getRightRect(self):
        return UiUtil.getBoundsInScreen(self.right.item)

    def getRect(self):
        rect = None
        if self.root is not None:
            rect = UiUtil.getBoundsInScreen(self.root.item)
        elif self.address is not None:
            rect = UiUtil.getBoundsInScreen(self.address.item)
        elif self.link is not None:
            rect = UiUtil.getBoundsInScreen(self.link.item)
        elif self.video is not None:
            rect = UiUtil.getBoundsInScreen(self.video.item)
        elif self.pictureGroup is not None:
            rect = UiUtil.getBoundsInScreen(self.pictureGroup.item)
        elif self.picture is not None:
            rect = UiUtil.getBoundsInScreen(self.picture.item)
        elif self.shortVideo is not None:
            rect = UiUtil.getBoundsInScreen(self.shortVideo.item)
        elif self.text is not None:
            rect = UiUtil.getBoundsInScreen(self.text.item)
        dotRect = UiUtil.getBoundsInScreen(self.dotBtn.item)
        if rect:
            rect.right = dotRect.right
        else:
            rect = dotRect
        return rect


class Moments:
    def __init__(self) -> None:
        self.weAppName = "com.tencent.mm"
        self.moments = []
        self.person = ""

    def clean(self):
        self.moments = []
        self.person = ""

    def show(self):
        for moment in self.moments:
            moment.show()

    def getDotBtnClickMoment(self, clickedView):
        for moment in self.moments:
            if moment.isDotBtnClicked(clickedView):
                return moment
        return None

    def getSingleMoment(self):
        if UiUtil.getPackageName() != self.weAppName:
            Log.log("current pakeage is not mm")
            return
        frientMoments = ListView()
        if not frientMoments.exist(timeout=0):
            return
        # frientMoments.show()
        for i in range(min(1, frientMoments.getChildCount())):
            child = frientMoments.getChild(i)
            moment = SingleMomentFactory.create(child)
            if moment is not None:
                self.moments.append(moment)

    def getCurrentMoments(self):
        if UiUtil.getPackageName() != self.weAppName:
            Log.log("current pakeage is not mm")
            return
        frientMoments = RecyclerView()
        if not frientMoments.exist(timeout=0):
            return
        # frientMoments.show()
        for i in range(frientMoments.getChildCount()):
            child = frientMoments.getChild(i)
            moment = MomentFactory().create(child)
            if moment is not None:
                self.moments.append(moment)

    def getPersonMoments(self, fromIndex, toIndex):
        if UiUtil.getPackageName() != self.weAppName:
            Log.log("current pakeage is not mm")
            return
        
        self.person = PersonMomentFactory.getPersonName()

        frientMoments = ListView()
        if not frientMoments.exist(timeout=0):
            return
        if frientMoments.getChildCount() != toIndex-fromIndex+1:
            return
        moments = []
        for i in range(frientMoments.getChildCount()):
            child = frientMoments.getChild(i)
            if child.exist() == False:
                return
            moment = PersonMomentFactory().create(child)
            if moment is not None:
                moment.ind = fromIndex + i
                if moment.ind < 2:
                    return
                moment.releaseDate = moment.personMomentGetDate()
                moment.releaseType = moment.personMomentGetType()
                moment.releaseText = moment.personMomentGetText()
                moments.append(moment)
        self.addMemonts(moments)
    
    def addMemonts(self, moments):
        def updateOrInsert(lst, newItem):
            for i, item in enumerate(lst):
                if item.ind == newItem.ind:
                    # 更新元素
                    lst[i] = newItem
                    return lst
                if item.ind > newItem.ind:
                    lst.insert(i, newItem)
                    return lst

            lst.append(newItem)
            return lst

        for moment in moments:
            self.moments = updateOrInsert(self.moments, moment)


class PersonMomentFactory:
    def getPersonName():
        iv = ImageView(description=",我的头像,")
        if iv.exist(timeout=0):
            return iv.getDescription().split(",我的头像,")[0].strip()
        vg = ViewGroup()
        if vg.getChildCount()!=2:
            return ""
        nameUI = vg.getChild(1)
        name = NodeHelp.getText(nameUI)
        return name.strip()

    def getLeftDate(ui: UIControl, moment):
        if ui.getChild(0).getClassName() != "LinearLayout":
            return False
        moment.left = ui.getChild(0)
        return True

    def getRightInfo(ui: UIControl, moment):
        if ui.getChild(1).getClassName() != "LinearLayout" and ui.getChild(1).getClassName() != "RelativeLayout":
            return False
        moment.right = ui.getChild(1)
        return True

    @staticmethod
    def create(rootNode: UIControl) -> Moment:
        if rootNode is None:
            return None
        if rootNode.getClassName() != "LinearLayout":
            return None
        if rootNode.getChildCount() == 0:
            return None
        ui = rootNode.getChild(rootNode.getChildCount()-1)
        if ui is None or ui.getChildCount() < 2:
            return None
        moment = Moment()
        moment.root = rootNode
        if not PersonMomentFactory.getLeftDate(ui, moment):
            return None
        if not PersonMomentFactory.getRightInfo(ui, moment):
            return None
        return moment


class SingleMomentFactory:
    nextAnlyseItem = []

    @staticmethod
    def create(momentUi: UIControl):
        avatar = ImageView(momentUi, description="的头像")
        if not avatar.exist():
            return None
        momentUi = avatar.getParent()
        if momentUi.getClassName() != "LinearLayout":
            # 可能是FrameLayout, 朋友圈的封面及头像部分
            # 也可能是广告
            return None
        if momentUi.getChildCount() != 3:
            return None
        moment = Moment()
        if not SingleMomentFactory.getAvatar(momentUi, moment):
            return None
        return SingleMomentFactory.anlyseMoment(momentUi.getChild(2), moment)

    @staticmethod
    def getAvatar(momentUi: UIControl, moment):
        avatar = momentUi.getChild(1)
        if avatar.getClassName() != "ImageView":
            return False
        if "头像" not in avatar.getDescription():
            return False
        moment.avatar = avatar
        return True

    @staticmethod
    def getDotBtn(momentUi: UIControl, moment):
        if momentUi.getChild(momentUi.getChildCount()-1).getClassName() == "ImageButton":
            moment.dotBtn = momentUi.getChild(momentUi.getChildCount()-1)
        return moment

    @staticmethod
    def anlyseMoment(momentUi: UIControl, moment):
        # momentUi.show()
        if momentUi.getClassName() != "RelativeLayout":
            return None
        if momentUi.getChildCount() < 5:
            Log.log(f"{momentUi.getChildCount()}")
            return None
        SingleMomentFactory.getDotBtn(momentUi, moment)

        realMomentUi = momentUi.getChild(2)
        SingleMomentFactory.nextAnlyseItem = [SingleMomentFactory.setName]
        for i in range(realMomentUi.getChildCount()):
            item = realMomentUi.getChild(i)
            for fun in SingleMomentFactory.nextAnlyseItem:
                if fun(item, moment):
                    break

        return moment

    def setName(item, moment):
        if item.getClassName() == "LinearLayout" and item.getChildCount() > 0:
            moment.name = item.getChild(0)
            SingleMomentFactory.nextAnlyseItem = [
                SingleMomentFactory.setText,
                SingleMomentFactory.setLink,
                SingleMomentFactory.setVideo,
                SingleMomentFactory.setPictureGroup,
                SingleMomentFactory.setShortVideo,]
        return True

    def setText(item, moment):
        if item.getClassName() == "TextView":
            moment.text = item
            SingleMomentFactory.nextAnlyseItem = [
                SingleMomentFactory.setLink,
                SingleMomentFactory.setVideo,
                SingleMomentFactory.setPictureGroup,
                SingleMomentFactory.setShortVideo,]
            return True
        return False

    def setLink(item, moment):
        if item.getClassName() != "LinearLayout" and item.getChildCount() == 0:
            return False
        realMomentUi = item.getChild(0)
        if realMomentUi.getClassName() == "LinearLayout":
            if realMomentUi.getChildCount() > 0:
                if realMomentUi.getChild(0).getClassName() == "LinearLayout":
                    moment.link = realMomentUi
                    SingleMomentFactory.nextAnlyseItem = [SingleMomentFactory.setAddress,]
                    return True
        return False

    def setVideo(item, moment):
        if item.getClassName() != "LinearLayout" and item.getChildCount() == 0:
            return False
        realMomentUi = item.getChild(0)
        if realMomentUi.getClassName() == "LinearLayout":
            if realMomentUi.getChildCount() > 0:
                if realMomentUi.getChild(0).getClassName() == "FrameLayout":
                    moment.video = realMomentUi
                    SingleMomentFactory.nextAnlyseItem = [SingleMomentFactory.setAddress,]
                    return True
        return False

    def setPictureGroup(item, moment):
        if item.getClassName() != "LinearLayout" and item.getChildCount() == 0:
            return False
        realMomentUi = item.getChild(0)
        if realMomentUi.getClassName() == "FrameLayout":
            moment.pictureGroup = realMomentUi
            SingleMomentFactory.nextAnlyseItem = [SingleMomentFactory.setAddress,]
            return True
        return False

    def setShortVideo(item, moment):
        if item.getClassName() != "LinearLayout" and item.getChildCount() == 0:
            return False
        realMomentUi = item.getChild(0)
        if realMomentUi.getClassName() == "ViewGroup":
            moment.shortVideo = realMomentUi
            SingleMomentFactory.nextAnlyseItem = [SingleMomentFactory.setAddress,]
            return True
        return False

    def setAddress(item, moment):
        if item.getClassName() == "TextView":
            moment.address = item
        SingleMomentFactory.nextAnlyseItem = []
        return True


class MomentFactory:
    nextAnlyseItem = []

    @staticmethod
    def create(rootNode: UIControl):
        if rootNode.getClassName() != "LinearLayout":
            # 可能是FrameLayout, 朋友圈的封面及头像部分
            # 也可能是广告
            Log.log("Maybe is AD or heart part, skip.")
            return None
        if rootNode.getChildCount() != 3:
            Log.log("ChildCount not equal to 3, skip.")
            return None
        # 因为不同版本，包含的层次不一样，为了准确的找到真实内容的父级别层
        # 所以采用了通过头像原始获取真正的父级
        avatar = ImageView(rootNode, description="头像")
        if not avatar.exist():
            return None
        momentUi = avatar.getParent()
        if momentUi.getChildCount() != 2:
            return None

        moment = Moment()
        if not MomentFactory.getAvatar(momentUi, moment):
            Log.log("getAvatar failed...")
            return None
        momentUi = momentUi.getChild(1)
        return MomentFactory.anlyseMoment(momentUi, moment)

    @staticmethod
    def getAvatar(momentUi: UIControl, moment):
        avatar = momentUi.getChild(0)
        if avatar.getClassName() != "ImageView":
            return False
        if avatar.getDescription() != "头像":
            avatar.show()
            return False
        moment.avatar = avatar
        return True

    @staticmethod
    def isAdvertisement(moment: UIControl):
        return moment.getChild(0).getClassName() == "LinearLayout"

    @staticmethod
    def getDotBtn(momentUi: UIControl, moment):
        other = momentUi.getChild(momentUi.getChildCount()-3)
        if other.getChildCount() != 2:
            return moment
        other = other.getChild(1)
        if other.getClassName() != "ImageView":
            return moment
        moment.dotBtn = other

        return moment

    @staticmethod
    def anlyseMoment(momentUi: UIControl, moment):
        if momentUi.getClassName() != "ViewGroup":
            return None
        if momentUi.getChildCount() < 4:
            return None
        if MomentFactory.isAdvertisement(momentUi):
            momentUi.advertisement = "AD"
            return momentUi
        MomentFactory.getDotBtn(momentUi, moment)
        # 后面三个是(发布时间和点赞等按钮, 朋友点赞和回复, 空)
        MomentFactory.nextAnlyseItem = [MomentFactory.setName]
        for i in range(momentUi.getChildCount()-3):
            item = momentUi.getChild(i)
            for fun in MomentFactory.nextAnlyseItem:
                if fun(item, moment):
                    break
        return moment

    def setName(item, moment):
        if item.getClassName() == "TextView":
            moment.name = item
            MomentFactory.nextAnlyseItem = [
                MomentFactory.setText,
                MomentFactory.setLink,
                MomentFactory.setVideo,
                MomentFactory.setPictureGroup,
                MomentFactory.setPicture,
                MomentFactory.setShortVideo,]
            return True
        return False

    def setText(item, moment):
        if item.getClassName() == "LinearLayout" and item.getChildCount() > 0:
            if item.getChild(0).getClassName() == "TextView":
                moment.text = item.getChild(0)
                MomentFactory.nextAnlyseItem = [
                    MomentFactory.setLink,
                    MomentFactory.setVideo,
                    MomentFactory.setPictureGroup,
                    MomentFactory.setPicture,
                    MomentFactory.setShortVideo,]
                return True
        return False

    def setLink(item, moment):
        if item.getClassName() == "LinearLayout" and item.getChildCount() > 0:
            if item.getChild(0).getClassName() == "FrameLayout":
                moment.link = item
                MomentFactory.nextAnlyseItem = [MomentFactory.setAddress,]
                return True
        return False

    def setVideo(item, moment):
        if item.getClassName() == "RelativeLayout":
            moment.video = item
            MomentFactory.nextAnlyseItem = [MomentFactory.setAddress,]
            return True
        return False

    def setPictureGroup(item, moment):
        if item.getClassName() == "ViewGroup":
            moment.pictureGroup = item
            MomentFactory.nextAnlyseItem = [MomentFactory.setAddress,]
            return True
        return False

    def setPicture(item, moment):
        if item.getClassName() == "View" and item.getDescription() and "图片" in item.getDescription():
            moment.picture = item
            MomentFactory.nextAnlyseItem = [MomentFactory.setAddress,]
            return True
        return False

    def setShortVideo(item, moment):
        if item.getClassName() == "FrameLayout" and item.getChildCount() > 0:
            if item.getChild(0).getClassName() == "RelativeLayout":
                moment.shortVideo = item
                MomentFactory.nextAnlyseItem = [MomentFactory.setAddress,]
                return True
        return False

    def setAddress(item, moment):
        if item.getClassName() == "LinearLayout" and item.getChildCount() > 0:
            if item.getChild(0).getClassName() == "TextView":
                moment.address = item.getChild(0)
        MomentFactory.nextAnlyseItem = []
        return True
