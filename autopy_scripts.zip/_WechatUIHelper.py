import time
import importlib
importlib.reload(importlib.import_module("UiUtil"))
from UiUtil import (UiUtil,
                    TextView, RelativeLayout, ImageView, EditText)
from Log import Log
from com.xiaoyuan.weHelper import AutoService

class WechatUIHelper:
    def isMainUi():
        return TextView(text="发现").exist(timeout=1) and TextView(text="通讯录").exist(timeout=1) and TextView(text="微信").exist(timeout=1)

    def gotoMainUi():
        name = "com.tencent.mm"
        if UiUtil.getPackageName() != name:
            raise Exception("当前应用不是微信")
        while not WechatUIHelper.isMainUi():
            if UiUtil.getPackageName() != name:
                raise Exception("当前应用不是微信")
            UiUtil.performGlobalAction(AutoService.GLOBAL_ACTION_BACK)
    
    def gotoSelfMoments():
        TextView(text="发现").click()
        TextView(text="朋友圈").click()

    def gotoFriend(to):
        Log.log("点击搜索按钮")
        searchIcon = RelativeLayout(viewId="com.tencent.mm:id/jha")
        searchIcon.click(timeout=10)
        Log.log("设置搜索内容")
        searchEdit = EditText(viewId="com.tencent.mm:id/d98")
        searchEdit.setText(to)
        WechatUIHelper.checkPersonExist()
        Log.log("点击联系人")
        person = TextView(text=to, viewId="com.tencent.mm:id/odf")
        person.click()

    def checkPersonExist(wait=0.2):
        for _ in range(30):
            lxrIcon = TextView(text="联系人", viewId="com.tencent.mm:id/gzf")
            zcsyIcon = TextView(text="最常使用", viewId="com.tencent.mm:id/gzf")
            if lxrIcon.exist(0, wait) or zcsyIcon.exist(0, wait):
                return True
            time.sleep(0.1)
        raise Exception("用户不存在")

    def gotoMoments(to):
        ImageView(description="更多信息").click()
        TextView(text=to).click()
        TextView(text="朋友圈").exist()
        TextView(text="朋友圈").getParent().click(gesture=True, duration=10)

