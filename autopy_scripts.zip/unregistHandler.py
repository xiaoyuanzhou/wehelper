from com.xiaoyuan.weHelper import AutoService
from Log import Log
from _ThreadTask import ThreadTask

AutoService.getInstance().registerHandler(None, None)
ThreadTask.stop("AccessibiltyEventHandler")
Log.log("UnRegisterHandler Success!!!!!")
