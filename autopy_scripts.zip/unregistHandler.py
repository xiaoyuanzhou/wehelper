from com.xiaoyuan.weHelper import AutoService
from Log import Log
from UiUtil import llog
from _ThreadTask import ThreadTask

AutoService.getInstance().registerHandler(None, None)
ThreadTask.stop("AccessibiltyEventHandler")
Log.log("UnRegisterHandler Success!!!!!")
llog.log("UnRegisterHandler Success!!!!!")
llog.log("=="*25)