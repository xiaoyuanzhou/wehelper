from android import R as AndroidR
from android.os import Build
from android.graphics import PixelFormat
from android.view import MotionEvent
from android.view import View
from android.view import LayoutInflater
from android.view import Gravity
from android.view import WindowManager
from android.widget import ArrayAdapter
from com.xiaoyuan.weHelper import R
from com.xiaoyuan.weHelper import AutoService
import time
from Log import Log
from _UiUtil import UiUtil
from _MainThreadTask import MainThreadTask
from _ConcreteClickProxy import OnTouchListenerProxy, OnItemClickListenerProxy

from android.graphics.drawable import GradientDrawable
from android.graphics import Color
from _WindowManager import WindowManagerHelper

class TopMenu:
    def __init__(self, context, autoHide=True) -> None:
        self.context = context
        self.menu = None
        self.menuView = None
        self.hideTime = 0
        self.autoHide = autoHide
        self.width = 100

    def setMenu(self, menu):
        self.menu = menu
        self.menuItems = [i[0] for i in menu]
    
    def isShowed(self):
        Log.log(f"{self.menuView}")
        return self.menuView is not None

    def show(self, x, y):
        root = AutoService.getInstance().getRootInActiveWindow()
        winRect = UiUtil.getBoundsInScreen(root)
        MainThreadTask().run(self._show, x, winRect.bottom - y).wait()
        Log.log(f"{self.menuView}")

    def _show(self, x, y):
        if self.menuView is not None:
            self._hide()
            return
        if self.menu is None:
            return
        if time.time() - self.hideTime < 0.5:
            return
        self._createView()
        self.width = self._calArrayAdapterWidth()
        layoutParams = self._createLayoutParams(x, y, self.width)
        WindowManagerHelper.addView(self.menuView, layoutParams)

    def hide(self):
        if self.menuView is None:
            return
        MainThreadTask().run(self._hide).wait()

    def _hide(self):
        if self.menuView is None:
            return
        WindowManagerHelper.removeView(self.menuView)
        self.menuView = None

    def _onMenuItemClick(self, position):
        self._hide()
        if position >= len(self.menu):
            return
        menu = self.menu[position]
        if len(menu) < 2 or menu[1] is None:
            return
        menu[1]()

    def _onViewTouch(self, event):
        if (event.getAction() == MotionEvent.ACTION_OUTSIDE):
            self._hide()
            self.hideTime = time.time()
        return False

    def _createView(self):
        self.menuView = LayoutInflater.from_(
            self.context).inflate(R.layout.sub_menu, None)
        if self.autoHide:
            self.menuView.setOnTouchListener(
                OnTouchListenerProxy(self._onViewTouch))
        else:
            def L(x):
                Log.log(f"{x}")
                return False
            self.menuView.setOnTouchListener(
                OnTouchListenerProxy(L))

        listView = self.menuView.findViewById(R.id.items)
        adapter = ArrayAdapter(
            self.context, AndroidR.layout.simple_list_item_1,
            self.menuItems)
        listView.setAdapter(adapter)

        gradientDrawable = GradientDrawable()
        gradientDrawable.setShape(GradientDrawable.RECTANGLE)
        gradientDrawable.setCornerRadius(20)
        gradientDrawable.setColor(Color.GREEN)
        listView.setBackgroundDrawable(gradientDrawable)

        listView.setOnItemClickListener(
            OnItemClickListenerProxy(self._onMenuItemClick))

    def _calArrayAdapterWidth(self):
        listView = self.menuView.findViewById(R.id.items)
        adapter = listView.getAdapter()
        width = 0
        listItemView = None
        for i in range(adapter.getCount()):
            listItemView = adapter.getView(i, listItemView, listView)
            listItemView.measure(View.MeasureSpec.UNSPECIFIED,
                                View.MeasureSpec.UNSPECIFIED)
            if (listItemView.getMeasuredWidth() > width):
                width = listItemView.getMeasuredWidth()
        return width

    def _createLayoutParams(self, x, y, width):
        layoutParams = WindowManager.LayoutParams()
        layoutParams.x = x
        layoutParams.y = y
        layoutParams.width = width
        layoutParams.height = WindowManager.LayoutParams.WRAP_CONTENT
        layoutParams.flags = (WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                            | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                            | WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH
                            | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN)
        layoutParams.format = PixelFormat.RGBA_8888
        layoutParams.gravity = Gravity.LEFT | Gravity.BOTTOM
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O):
            layoutParams.type = WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY
        else:
            layoutParams.type = WindowManager.LayoutParams.TYPE_TOAST
        return layoutParams
