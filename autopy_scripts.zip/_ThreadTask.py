import sys, threading


class ThreadTask:
    tasks = {}

    def runOnce(task, taskName=None, *args, **kwargs):
        assert taskName is not None
        if taskName in ThreadTask.tasks:
            return False
        ThreadTask.run(task, taskName, *args, **kwargs)

    def run(task, taskName=None, *args, **kwargs):
        if taskName is None:
            threading.Thread(target=task, *args, **kwargs).start()
            return
        ThreadTask.stop(taskName)
        ThreadTask.tasks[taskName] = StopableThread(target=task, *args, **kwargs)
        ThreadTask.tasks[taskName].start()

    def stop(taskName):
        if taskName is None or taskName not in ThreadTask.tasks:
            return False
        if not ThreadTask.tasks[taskName].is_alive():
            return True
        ThreadTask.tasks[taskName].stop()
        ThreadTask.tasks[taskName].join()
        ThreadTask.tasks.pop(taskName)
        return True
    
    def stopAll():
        for name, task in ThreadTask.tasks.items():
            task.stop()
            task.join()
        ThreadTask.tasks.clear()


class StopableThread(threading.Thread):
    def __init__(self, target, *args, **keywords):
        threading.Thread.__init__(self, target=target, *args, **keywords) 
        self.killed = False

    def start(self): 
        self._run = self.run 
        self.run = self.settrace_and_run
        threading.Thread.start(self)
    
    def stop(self):
        self.killed = True

    def settrace_and_run(self):
        sys.settrace(self.globaltrace)
        self._run()

    def globaltrace(self, frame, event, arg):
        return self.localtrace if event == 'call' else None

    def localtrace(self, frame, event, arg):
        if self.killed and event == 'line':
            raise SystemExit()
        return self.localtrace
