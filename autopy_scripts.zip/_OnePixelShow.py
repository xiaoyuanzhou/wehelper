from android.graphics import PixelFormat
from android.os import Build
from android.view import WindowManager
from android.widget import LinearLayout
from com.xiaoyuan.weHelper import AutoService
from _MainThreadTask import MainThreadTask
from _WindowManager import WindowManagerHelper


class OnePixelShow:
    view = None
    def createView():
        if OnePixelShow.view is not None:
            return
        layout = LinearLayout(AutoService.getInstance())
        OnePixelShow.view = layout

    def createParams():
        params = WindowManager.LayoutParams(
            1, 1,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT)
        if Build.VERSION.SDK_INT < 26: #Build.VERSION_CODES.O
            params.type = WindowManager.LayoutParams.TYPE_TOAST
        params.alpha = 0.7
        return params

    def show():
        def _f():
            OnePixelShow.createView()
            params = OnePixelShow.createParams()
            WindowManagerHelper.addView(OnePixelShow.view, params)
        MainThreadTask().run(_f).wait()

    def hide():
        if OnePixelShow.view is None:
            return
        def _f():
            WindowManagerHelper.removeView(OnePixelShow.view)
            OnePixelShow.view = None
        MainThreadTask().run(_f).wait()

