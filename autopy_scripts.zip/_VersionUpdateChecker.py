import importlib
import sys, os
import datetime
import random
import zipfile
from android.os import Handler
from _WindowManager import WindowManagerHelper
from _ThreadTask import ThreadTask
from _global import G
from _Net import Net
from Log import Log
from java.lang import Runnable
from java import dynamic_proxy


class VersionUpdateChecker(dynamic_proxy(Runnable)):
    _handle = Handler()
    _lastCheckTime = None
    _cache_file = os.path.join(os.path.dirname(__file__), "_lastCheckTime.cache")

    @staticmethod
    def rerunIfVersionUpdated():
        VersionUpdateChecker.cancel()
        VersionUpdateChecker._handle.postDelayed(VersionUpdateChecker(), 1000 * 5)

    @staticmethod
    def cancel():
        VersionUpdateChecker._handle.removeCallbacksAndMessages(None)

    @staticmethod
    def loadNextCheckTime():
        if VersionUpdateChecker._lastCheckTime is not None:
            return
        if not os.path.exists(VersionUpdateChecker._cache_file):
            VersionUpdateChecker.updateNextCheckTime()
            return
        with open(VersionUpdateChecker._cache_file, 'r') as f:
            time_str = f.read().strip()
            try:
                VersionUpdateChecker._lastCheckTime = datetime.datetime.strptime(time_str, "%Y-%m-%d %H:%M:%S")
                Log.log(f"Next check version time: {time_str}")
                return
            except ValueError as e:
                print(f"ValueError: {e}")
        VersionUpdateChecker.updateNextCheckTime()

    @staticmethod
    def updateNextCheckTime():
        random_minutes = random.randint(8 * 60, 24 * 60)
        VersionUpdateChecker._lastCheckTime = datetime.datetime.now() + datetime.timedelta(minutes=random_minutes)
        time_str = VersionUpdateChecker._lastCheckTime.strftime("%Y-%m-%d %H:%M:%S")
        with open(VersionUpdateChecker._cache_file, 'w') as f:
            f.write(time_str)
        Log.log(f"Next check version time: {time_str}")

    def timeForVersionCheck(self):
        VersionUpdateChecker.loadNextCheckTime()
        return VersionUpdateChecker._lastCheckTime < datetime.datetime.now()

    def run(self):
        try:
            if not self.timeForVersionCheck():
                VersionUpdateChecker.rerunIfVersionUpdated()
                return
            VersionUpdateChecker.updateNextCheckTime()
            if not Net.versionUpdated():
                Log.log("当前已经是最新版本了")
                VersionUpdateChecker.rerunIfVersionUpdated()
                return
            Log.log("重新加载最新脚本")
            self._rerunDueToVersionUpdated()
        except:
            Log.log("异常, 重新加载最新脚本")
            self._rerunDueToVersionUpdated()

    def _rerunDueToVersionUpdated(self, script="main"):
        try:
            self._cleanCache()
            self._cleanOldModules()
            Log.log("cleanOldModules()")
            self._downloadNewScript()
            Log.log("downloadNewScript()")
            sys.path.append(os.path.dirname(__file__))
            importlib.import_module(script)
        except Exception as e:
            Log.log(e)

    def _downloadNewScript(self):
        newScriptFile = Net.getNewScript()
        if newScriptFile is None:
            return
        file=zipfile.ZipFile(newScriptFile)
        file.extractall(os.path.dirname(__file__))
        file.close()

    def _cleanCache(self):
        VersionUpdateChecker.cancel()
        WindowManagerHelper.removeAll()
        ThreadTask.stopAll()
        G.o.clear()

    def _cleanOldModules(self):
        reloadPath = os.path.dirname(__file__)
        need_del_modules = []
        for name, module in sys.modules.items():
            if reloadPath in str(module) and "__main__" != name:
                need_del_modules.append(name)
        for name in need_del_modules:
            module = sys.modules[name]
            sys.modules.pop(name)
            del module
