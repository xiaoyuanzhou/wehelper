from com.xiaoyuan.weHelper import AbstractClassCreater
from Log import Log

class JavaInt:
    def getClass():
        return AbstractClassCreater.getIntClass()[0]

# 构造时，没有指定参数名的参数都将传递给被代理类
# 如果作为Java参数的，需要传递对象的proxied，这个才是真正的java对象，或者调用toJava
def JavaProxy(target_class, *consArgs):
    def my_decorator(cls):
        orig_init = cls.__init__
        def hasFunc(self, methodName):
            return methodName in cls.__dict__
        def toJava(self):
            return self.proxied
        def initWithProxiedClass(self, *args, **kwargs):
            orig_init(self, *args, **kwargs)
            newConsArgs = [cons.getClass() for cons in consArgs] if len(consArgs)>0 else None
            obj = AbstractClassCreater.newInstance(
                target_class.getClass(), self, newConsArgs, args)
            setattr(self, "proxied", obj)
        def new_getattr(self, method):
            return getattr(self.proxied, method)
        cls.hasFunc = hasFunc
        cls.toJava = toJava
        cls.__init__ = initWithProxiedClass
        cls.__getattr__ = new_getattr
        return cls
    return my_decorator
