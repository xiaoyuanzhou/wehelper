from com.xiaoyuan.weHelper import R

def onCreate(context):
    pass
