from com.xiaoyuan.weHelper import AutoService
from android.content import Context

class WindowManagerHelper:
    addedViews = []

    def removeView(view):
        if view in WindowManagerHelper.addedViews:
            WindowManagerHelper.addedViews.remove(view)
        try:
            WindowManagerHelper.windowManager().removeView(view)
        except:
            pass

    def addView(view, layoutParams):
        WindowManagerHelper.addedViews.append(view)
        WindowManagerHelper.windowManager().addView(view, layoutParams)

    def updateViewLayout(view, layoutParams):
        try:
            WindowManagerHelper.windowManager().updateViewLayout(view, layoutParams)
        except:
            pass
    
    def removeAll():
        for view in WindowManagerHelper.addedViews:
            try:
                WindowManagerHelper.windowManager().removeView(view)
            except:
                pass
        WindowManagerHelper.addedViews = []
    
    def windowManager():
        return AutoService.getInstance().getSystemService(Context.WINDOW_SERVICE)